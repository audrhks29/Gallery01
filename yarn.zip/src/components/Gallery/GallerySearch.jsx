import { useRef, useState } from 'react';
import { GallerySearchForm } from '../styled/galleryStyle.js'
import { AiOutlineCloseCircle } from 'react-icons/ai';

const GallerySearch = ({ onSearch }) => {
    let no = useRef(0);
    const [text, setText] = useState('')
    const [memory, setMemory] = useState([])
    const onSubmit = (e) => {
        e.preventDefault()
        if (!text) return
        onSearch(text)
        setMemory([...memory, { id: no.current++, text }])
        // memory.push({ id: no.current++, text: text })
        // setMemory(memory)
        console.log(memory);
    }

    const memoryDel = (id) => {
        setMemory(memory.filter(item => { item.id !== id }))
        console.log(memory)
        console.log(id);
    }
    return (
        <GallerySearchForm onSubmit={onSubmit}>
            <input type="text" onChange={(e) => setText(e.target.value)} value={text} />
            <button type='submit'>검색</button>
            <ul>
                {
                    memory.map(item => (
                        <li key={item.id}>{item.text}<i onClick={() => memoryDel(item.id)}><AiOutlineCloseCircle /></i></li>
                    ))
                }
                {/* <button onClick={() => setText('')}>초기화</button> */}
            </ul>
        </GallerySearchForm>
    );
};

export default GallerySearch;