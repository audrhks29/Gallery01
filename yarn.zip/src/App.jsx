import React from 'react';
import GlobalStyle from './components/styled/GlobalStyle';
import Gallery from './components/Gallery/Gallery';

const App = () => {
  return (

    <>
      <GlobalStyle />
      <Gallery />
      <h2>hi</h2>
    </>
  );
};

export default App;